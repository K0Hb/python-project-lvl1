#!/usr/bin/env python

from brain_games.body_progression import body_progression


def brain_progression():
    print('Welcome to the Brain Games!')
    body_progression()


if __name__ == '__main__':
    brain_progression()
