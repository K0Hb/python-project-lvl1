#!/usr/bin/env python

from brain_games.body_gcd import body_gcd


def brain_gcd():
    print('Welcome to the Brain Games!')
    body_gcd()


if __name__ == '__main__':
    brain_gcd()
