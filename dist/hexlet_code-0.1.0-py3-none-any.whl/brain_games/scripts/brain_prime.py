#!/usr/bin/env python

from brain_games.body_prime import body_prime


def brain_prime():
    print('Welcome to the Brain Games!')
    body_prime()


if __name__ == '__main__':
    brain_games()