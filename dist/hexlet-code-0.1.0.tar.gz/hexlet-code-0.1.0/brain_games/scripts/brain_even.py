#!/usr/bin/env python

from brain_games.questions import list_quest


def brain_even():
    print('Welcome to the Brain Games!')
    list_quest()


if __name__ == '__main__':
    brain_even()
